# Requirements

- [Home](Home)
- [Project README](Project-README)
- [Architecture Overview](Architecture-Overview)
- [CSDb Integration](CSDb-Integration)
- [RomM Client Libraries](RomM-Client-Libraries)
- [HVSC in Container](HVSC-in-Container)
- [GameBase64 Tag Mapping](GameBase64-Tag-Mapping)
- [Functional Requirements](Functional-Requirements)
- [Technical Requirements](Technical-Requirements)
- [Testing Requirements](Testing-Requirements)
- [TR per FR Mapping](TR-per-FR-Mapping)
- [Requirements Matrix](Requirements-Matrix)
